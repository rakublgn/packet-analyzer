import pyshark

# Path to your pcap file
capture_file = 'assignment.pcapng'

# Open the capture file
cap = pyshark.FileCapture(capture_file)

# Function to analyze packets
def analyze_pcap():
    print("Analyzing packets in the file:", capture_file)
    print("=" * 60)
    
    for packet in cap:
        try:
            print(f"Packet Number: {packet.number}")
            print(f"Timestamp: {packet.sniff_time}")
            print(f"Packet Length: {packet.length} bytes")
            
            # Extract IP layer information
            if 'IP' in packet:
                print(f"  Source IP: {packet.ip.src}")
                print(f"  Destination IP: {packet.ip.dst}")
            
            # Extract TCP/UDP layer information
            if 'TCP' in packet:
                print(f"  TCP Source Port: {packet.tcp.srcport}")
                print(f"  TCP Destination Port: {packet.tcp.dstport}")
            elif 'UDP' in packet:
                print(f"  UDP Source Port: {packet.udp.srcport}")
                print(f"  UDP Destination Port: {packet.udp.dstport}")

            print("-" * 60)
        except AttributeError as e:
            print(f"Error processing packet: {e}")
            continue

# Call the analysis function
try:
    analyze_pcap()
except KeyboardInterrupt:
    print("\nStopped analysis.")
finally:
    cap.close()
