import pyshark
from flask import Flask, render_template, jsonify

app = Flask(__name__)

# Path to your pcap file
capture_file = 'assignment.pcapng'

# Open the capture file
cap = pyshark.FileCapture(capture_file)

# Function to analyze packets and group them by protocol
def analyze_pcap():
    grouped_packets = {
        'TCP': [],
        'UDP': [],
        'Other': [],
    }
    
    for packet in cap:
        packet_info = {}
        try:
            packet_info['number'] = packet.number
            packet_info['timestamp'] = packet.sniff_time.isoformat()
            packet_info['length'] = packet.length
            
            # Extract IP layer information
            if 'IP' in packet:
                packet_info['src_ip'] = packet.ip.src
                packet_info['dst_ip'] = packet.ip.dst
            
            # Extract TCP/UDP layer information
            if 'TCP' in packet:
                packet_info['src_port'] = packet.tcp.srcport
                packet_info['dst_port'] = packet.tcp.dstport
                packet_info['protocol'] = 'TCP'
                grouped_packets['TCP'].append(packet_info)
            elif 'UDP' in packet:
                packet_info['src_port'] = packet.udp.srcport
                packet_info['dst_port'] = packet.udp.dstport
                packet_info['protocol'] = 'UDP'
                grouped_packets['UDP'].append(packet_info)
            else:
                packet_info['protocol'] = 'Other'
                grouped_packets['Other'].append(packet_info)
        except AttributeError as e:
            print(f"Error processing packet: {e}")
            continue
    
    cap.close()  # Close the capture file after processing
    return grouped_packets

# Route to display packet information, grouped by protocol
@app.route('/')
def index():
    grouped_packets = analyze_pcap()  # Get grouped packet data
    return render_template('index.html', grouped_packets=grouped_packets)

# Route to provide packet data in JSON format for API requests
@app.route('/api/packets', methods=['GET'])
def get_packets():
    grouped_packets = analyze_pcap()  # Get grouped packet data
    return jsonify(grouped_packets)

if __name__ == '__main__':
    app.run(debug=True)
